package com.njupt.fragmentdemo;

import com.example.fragmentdemo.R;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WeixinFragment extends Fragment{
	private EditText weixin_text; 
	private Button weixin_button;
	
	public interface weixin_callback {
        public void onWeinxin_button_click(String text);
    }
	
	private weixin_callback mCallback;
	
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		
		try {
			mCallback = (weixin_callback) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement weixin_callback");
        }
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState)
	{
		Toast.makeText(getActivity(),  
                "enter WeixinFragment  onCreateView ",  
                Toast.LENGTH_SHORT).show();
		View view =  inflater.inflate(R.layout.fragment_weixin, container, false);
		
		weixin_text = (EditText) view.findViewById(R.id.weixin_text);
		
		weixin_button = (Button) view.findViewById(R.id.weinxin_button1);
		weixin_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mCallback.onWeinxin_button_click(weixin_text.getText().toString());
			}
		});
		
		return view;
	}
	
	@Override
	public void onDestroyView() {
		Toast.makeText(getActivity(),  
                "enter WeixinFragment  onDestroyView ",  
                Toast.LENGTH_SHORT).show();
		super.onDestroyView();
	}
}
