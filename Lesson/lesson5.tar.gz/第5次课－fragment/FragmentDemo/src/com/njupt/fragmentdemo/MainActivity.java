package com.njupt.fragmentdemo;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;

import com.example.fragmentdemo.R;

//implements WeixinFragment.weixin_callback
public class MainActivity extends Activity implements OnClickListener, WeixinFragment.weixin_callback{

	private ImageButton mTabWeixin;
	private ImageButton mTabFriend;
	private ImageButton mTabContract;
	private ImageButton mTabSetting;

	private WeixinFragment mWeixin;
	private FriendFragment mFriend;
	private ContractFragment mContract;
	private SettingFragment mSetting;
	private TitleFragment mTitleFragment;
	
	@Override
	public void onWeinxin_button_click(String text){
		mTitleFragment.setTitleText(text);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		mTitleFragment =(TitleFragment) getFragmentManager().findFragmentById(R.id.id_fragment_title);
		// ��ʼ���ؼ��������¼�
		mTabWeixin = (ImageButton) findViewById(R.id.tab_bottom_weixin);
		mTabFriend = (ImageButton) findViewById(R.id.tab_bottom_friend);
		mTabContract = (ImageButton) findViewById(R.id.tab_bottom_contract);
		mTabSetting = (ImageButton) findViewById(R.id.tab_bottom_setting);
		mTabWeixin.setOnClickListener(this);
		mTabFriend.setOnClickListener(this);
		mTabContract.setOnClickListener(this);
		mTabSetting.setOnClickListener(this);
		// ����Ĭ�ϵ�Fragment
		setDefaultFragment();
	}

	private void setDefaultFragment()
	{
		FragmentManager fm = getFragmentManager();
		FragmentTransaction transaction = fm.beginTransaction();
		mWeixin = new WeixinFragment();
		transaction.replace(R.id.id_content, mWeixin);
		transaction.commit();
	}

	@Override
	public void onClick(View v)
	{
		FragmentManager fm = getFragmentManager();
		// ����Fragment����
		FragmentTransaction transaction = fm.beginTransaction();
		
		Fragment current = fm.findFragmentById(R.id.id_content);

		switch (v.getId())
		{
		case R.id.tab_bottom_weixin:
			mTitleFragment.setTitleText("΢��");
			if (mWeixin == null)
			{
				mWeixin = new WeixinFragment();
			}
			// ʹ�õ�ǰFragment�Ĳ������id_content�Ŀؼ�
			//transaction.replace(R.id.id_content, mWeixin);
			transaction.hide(current);
			transaction.add(R.id.id_content, mWeixin);
			break;
		case R.id.tab_bottom_friend:
			mTitleFragment.setTitleText("����");
			if (mFriend == null)
			{
				mFriend = new FriendFragment();
			}
			//transaction.replace(R.id.id_content, mFriend);
			transaction.hide(current);
			transaction.add(R.id.id_content, mFriend);
			break;
		case R.id.tab_bottom_contract:
			mTitleFragment.setTitleText("ͨѶ¼");
			if (mContract == null)
			{
				mContract = new ContractFragment();
			}
			//transaction.replace(R.id.id_content, mContract);
			transaction.hide(current);
			transaction.add(R.id.id_content, mContract);
			break;
		case R.id.tab_bottom_setting:
			mTitleFragment.setTitleText("����");
			if (mSetting == null)
			{
				mSetting = new SettingFragment();
			}
			//transaction.replace(R.id.id_content, mSetting);
			transaction.hide(current);
			transaction.add(R.id.id_content, mSetting);	
			break;
		}
		// ���뵽����ջ
		transaction.addToBackStack(null);
		// �����ύ
		transaction.commit();
	}
}
