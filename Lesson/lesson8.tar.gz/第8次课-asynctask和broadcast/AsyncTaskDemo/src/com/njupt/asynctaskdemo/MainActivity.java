package com.njupt.asynctaskdemo;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener {
    TextView text;
    TextView tv_progress;
    
    ProgressBar pb;
    
    Button btn_read;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (TextView)findViewById(R.id.textView1);
        tv_progress = (TextView)findViewById(R.id.tv_progress);
        pb = (ProgressBar)findViewById(R.id.pb);
        btn_read = (Button)findViewById(R.id.read);
        btn_read.setOnClickListener(this);    
    }
    
	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		    case R.id.read:
		    	ReadURL("http://www.baidu.com");
		}
	}
	
	public void ReadURL(String url) {
		DownloadTask task = new DownloadTask();
		task.execute(url);
	}
	
	
	class DownloadTask extends AsyncTask<String, Integer, String> {

		@Override
		protected String doInBackground(String... params) {
			// ����1��ͨ��HttpURLConnection
			try {
				URL url = new URL(params[0]);
				URLConnection connection = url.openConnection();
				InputStream iStream =connection.getInputStream();
				
				InputStreamReader isr = new InputStreamReader(iStream);
				BufferedReader br = new BufferedReader(isr);
				
				String line;
				StringBuilder builder = new StringBuilder();
				while((line=br.readLine()) != null) {
					builder.append(line);
					Thread.sleep(500);
				}
				br.close();
				iStream.close();
				return builder.toString();
				
			} catch (MalformedURLException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "";
			
			// ��������ͨ��HttpClient
//			try {
//				HttpClient client = new DefaultHttpClient();
//				HttpGet get = new HttpGet(params[0]);
//				HttpResponse response = client.execute(get);
//				if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
//					HttpEntity entity = response.getEntity();
//					InputStream is = entity.getContent();
//					long total = entity.getContentLength();
//					ByteArrayOutputStream baos = new ByteArrayOutputStream();
//					byte[] buf = new byte[1024];
//					int count = 0;
//					int length = -1;
//					while ((length = is.read(buf)) != -1) {
//						baos.write(buf, 0, length);
//						count += length;
//						//����publishProgress��������,���onProgressUpdate��������ִ��
//						//publishProgress((int) ((count / (float) total) * 100));
//						//Ϊ����ʾ����,����500����
//						//Thread.sleep(500);
//					}
//					return new String(baos.toByteArray(), "gb2312");
//				}
//			} catch (Exception e) {
//				
//			}
//			return null;
			
//			for(int i=0;i<=100;i++){   
//                publishProgress(i);  
//                try {  
//                    Thread.sleep(500);  
//                } catch (InterruptedException e) {  
//                    e.printStackTrace();  
//                }  
//            }  
//            return "ִ�����";
		}

//		@Override
//		protected void onProgressUpdate(Integer... progress) {
//			tv_progress.setText(progress[0]+"%");
//			pb.setProgress(progress[0]);
//			super.onProgressUpdate(progress);
//		}
		
		@Override
		protected void onPostExecute(String result) {
			text.setText(result);
			super.onPostExecute(result);
		}
	}
    
    
}
