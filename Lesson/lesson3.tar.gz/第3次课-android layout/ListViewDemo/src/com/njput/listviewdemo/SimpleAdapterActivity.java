package com.njput.listviewdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bgxt.datatimepickerdemo.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class SimpleAdapterActivity extends Activity {
	private ListView listview;
	private SimpleAdapter simpleAdapter;
	private List<Map<String, Object>> data;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_listviewarrayadapter);
		listview = (ListView) findViewById(R.id.lvArray);
		//�������
		putData();
		//����ʹ�õ�ǰ�Ĳ�����Դ��ΪListView��ģ�塣
		//ʹ�����ַ�ʽ��SimpleAdapter�����ListView�ؼ�������ListView֮��Ŀؼ���Ϊģ�塣
		simpleAdapter = new SimpleAdapter(SimpleAdapterActivity.this, data,
				R.layout.activity_listviewarrayadapter, new String[] { "icon",
						"name", "ss" }, new int[] { R.id.ivIcon, R.id.tvName,
						R.id.tvSS });
		listview.setAdapter(simpleAdapter);
		listview.setOnItemClickListener(callback);
		
	}
	
	private OnItemClickListener callback = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			
			String info = "�����˵�" + Integer.toString(position+1) + "��item\n, ����Ϊ��" + 
					(String)data.get(position).get("name") + "\n ǩ��Ϊ:" +
					(String)data.get(position).get("ss");
			Toast.makeText(SimpleAdapterActivity.this, info, Toast.LENGTH_SHORT).show();
				
		}
		
	};
	
	private void putData()
	{
		data=new ArrayList<Map<String,Object>>();
		Map<String, Object> map1=new HashMap<String, Object>();
		map1.put("icon", R.drawable.item1);
		map1.put("name", "��");
		map1.put("ss", "�罫����ҹ��;");
		Map<String, Object> map2=new HashMap<String, Object>();
		map2.put("icon", R.drawable.item2);
		map2.put("name", " İ İ");
		map2.put("ss", "Ѱ����,����������__��");
		Map<String, Object> map3=new HashMap<String, Object>();
		map3.put("icon", R.drawable.item3);
		map3.put("name", "ϫ��");
		map3.put("ss", "���·���:�й��ϻ���������22�仰...");
		Map<String, Object> map4=new HashMap<String, Object>();
		map4.put("icon", R.drawable.item4);
		map4.put("name", "������");
		map4.put("ss", " ");
		data.add(map1);
		data.add(map2);
		data.add(map3);
		data.add(map4);
	}
}
