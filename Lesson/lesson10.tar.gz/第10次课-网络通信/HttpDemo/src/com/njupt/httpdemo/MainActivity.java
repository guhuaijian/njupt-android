package com.njupt.httpdemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener {
    EditText fanyi_content;
	TextView fanyi_result;
	Button btn_testHttpGet;
	Button btn_testHttpPost;
	Button btn_testHttpClientGet;
	Button btn_testHttpClientPost;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        fanyi_content = (EditText) findViewById(R.id.fanyitext);
        fanyi_result = (TextView) findViewById(R.id.fanyi_result);
        
        btn_testHttpGet = (Button) findViewById(R.id.httpget);
        btn_testHttpGet.setOnClickListener(this);
        
        btn_testHttpPost = (Button) findViewById(R.id.httppost);
        btn_testHttpPost.setOnClickListener(this);
        
        btn_testHttpClientGet = (Button) findViewById(R.id.httpclientget);
        btn_testHttpClientGet.setOnClickListener(this);
        
        btn_testHttpClientPost = (Button) findViewById(R.id.httpclientpost);
        btn_testHttpClientPost.setOnClickListener(this);
    }
    
    @Override
	public void onClick(View v) {
		switch (v.getId()) {
		        // ͨ��java.net.HttpURLConnection��put����������http����
				case R.id.httpget: {
					String url = "http://fanyi.youdao.com/openapi.do?keyfrom=njuptandroid&key=1463345618&type=data&doctype=json&version=1.1&q="
							+ fanyi_content.getText();
					new HttpGetTask().execute(url);
					break;
				}

				// ͨ��java.net.HttpURLConnection��post����������http����
				case R.id.httppost: {
					new HttpPostTask().execute("http://fanyi.youdao.com/openapi.do");
					break;
				}

				case R.id.httpclientget: {
					String url = "http://fanyi.youdao.com/openapi.do?keyfrom=njuptandroid&key=1463345618&type=data&doctype=json&version=1.1&q="
							+ fanyi_content.getText();
					new HttpClientGetTask().execute(url);
					break;
				}

				case R.id.httpclientpost: {
					new HttpClientPostTask()
							.execute("http://fanyi.youdao.com/openapi.do");
					break;
				}
		}

	}
    
    class HttpGetTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			try {
				URL url = new URL(params[0]);
				URLConnection connection = url.openConnection();
				InputStream is = connection.getInputStream();
				InputStreamReader isr = new InputStreamReader(is,"utf-8");
				BufferedReader br = new BufferedReader(isr);
				
				String line;
				StringBuilder builder = new StringBuilder();
				
				while((line = br.readLine()) != null){
					builder.append(line).append("\r\n");
				}
				br.close();
				isr.close();
				is.close();
				return builder.toString();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;	
		}

		@Override
		protected void onPostExecute(String result) {
			fanyi_result.setText(result);
			super.onPostExecute(result);
		}	
    }
    
    
    class HttpPostTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			try {
				URL url =  new URL(params[0]);
				// ���ô���
//				Proxy proxy=new Proxy(java.net.Proxy.Type.HTTP,new InetSocketAddress("10.0.0.172",80));
//				HttpURLConnection connection = (HttpURLConnection)url.openConnection(proxy);
				HttpURLConnection connection = (HttpURLConnection)url.openConnection();
				
				connection.setDoOutput(true);
				connection.setRequestMethod("POST");
				
				OutputStream os =  connection.getOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(os);
				BufferedWriter bw = new BufferedWriter(osw);
				bw.write("keyfrom=njuptandroid&key=1463345618&type=data&doctype=xml&version=1.1&q=" + fanyi_content.getText());
				bw.flush();
				
				InputStream is = connection.getInputStream();
				InputStreamReader isr = new InputStreamReader(is,"utf-8");
				BufferedReader br = new BufferedReader(isr);
				
				String line;
				StringBuilder builder = new StringBuilder();
				
				while((line = br.readLine()) != null){
					builder.append(line).append("\r\n");
				}
				br.close();
				isr.close();
				is.close();
				return builder.toString();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;	
		}

		@Override
		protected void onPostExecute(String result) {
			fanyi_result.setText(result);
			super.onPostExecute(result);
		}	
    }
    
    class HttpClientGetTask extends AsyncTask<String, Void, String> {
		@Override
		protected String doInBackground(String... params) {
			String result = "";
			try {
				String urlString = params[0];
				HttpGet get = new HttpGet(urlString);
				
				HttpClient client = new DefaultHttpClient();
//              // ����������     
//              HttpHost proxy = new HttpHost("10.60.8.20", 8080);     
//              client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy); 
				
				// ִ�У����������������
				HttpResponse response = client.execute(get);
				
				// �Է��������ص����ݽ��д���
				int statuscode = response.getStatusLine().getStatusCode();
				if(statuscode == HttpStatus.SC_OK) {
					HttpEntity entity = response.getEntity(); 
					result = EntityUtils.toString(response.getEntity());
					
					// ��ʾ���
//					InputStream is = entity.getContent();
//					InputStreamReader isr = new InputStreamReader(is, "utf-8");
//					BufferedReader reader = new BufferedReader(isr);
//
//					StringBuilder builder = new StringBuilder();
//					String line = null;
//					while ((line = reader.readLine()) != null) {
//						builder.append(line).append("\r\n");
//					}
//					reader.close();
//					isr.close();
//					is.close();
//
//					if (entity != null) {
//						entity.consumeContent();
//					}
//					result = builder.toString();
				}	
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;	
		}

		@Override
		protected void onPostExecute(String result) {
			fanyi_result.setText(result);
			super.onPostExecute(result);
		}	
    }
    
    
    class HttpClientPostTask extends AsyncTask<String, Void, String> {
		@Override
		protected String doInBackground(String... params) {
			String result = "";
			String urlString = params[0];
	        try {
				HttpPost post = new HttpPost(urlString);
				// post ���� ����  
				//keyfrom=njuptandroid&key=1463345618&type=data&doctype=xml&version=1.1&q=
		        List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();  
		        nvps.add(new BasicNameValuePair("keyfrom", "njuptandroid"));   
		        nvps.add(new BasicNameValuePair("key", "1463345618")); 
		        nvps.add(new BasicNameValuePair("type", "data")); 
		        nvps.add(new BasicNameValuePair("doctype", "xml"));
		        nvps.add(new BasicNameValuePair("version", "1.1")); 
		        nvps.add(new BasicNameValuePair("q", fanyi_content.getText().toString()));
				post.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
				
				// ִ�У����������������
				HttpClient client = new DefaultHttpClient();
				HttpResponse response = client.execute(post);
				
				// �Է��������ص����ݽ��д���
				int statuscode = response.getStatusLine().getStatusCode();
				if(statuscode == HttpStatus.SC_OK) {
					HttpEntity entity = response.getEntity(); 
					//result = EntityUtils.toString(response.getEntity());
					
					// ��ʾ���
					InputStream is = entity.getContent();
					InputStreamReader isr = new InputStreamReader(is, "utf-8");
					BufferedReader reader = new BufferedReader(isr);

					StringBuilder builder = new StringBuilder();
					String line = null;
					while ((line = reader.readLine()) != null) {
						builder.append(line).append("\r\n");
					}
					reader.close();
					isr.close();
					is.close();

					if (entity != null) {
						entity.consumeContent();
					}
					result = builder.toString();
				}
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			return result;	
		}

		@Override
		protected void onPostExecute(String result) {
			fanyi_result.setText(result);
			super.onPostExecute(result);
		}	
    }
 
}
