package com.example.xmljsondemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.app.Activity;
import android.os.Bundle;
import android.util.Xml;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener{

	TextView tv_result;
	Button btn_parsexmlbydom;
	Button btn_parsexmlbysax;
	Button btn_parsexmlbypull;
	Button btn_genxml;
	Button btn_parsejson;
	Button btn_genjson;
	StringBuilder str_builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
       tv_result = (TextView) findViewById(R.id.result);
        
       btn_parsexmlbydom = (Button) findViewById(R.id.parsexmlbydom);
       btn_parsexmlbydom.setOnClickListener(this);
       
       btn_parsexmlbysax = (Button) findViewById(R.id.parsexmlbysax);
       btn_parsexmlbysax.setOnClickListener(this);
       
       btn_parsexmlbypull = (Button) findViewById(R.id.parsexmlbypull);
       btn_parsexmlbypull.setOnClickListener(this);
        
       btn_genxml = (Button) findViewById(R.id.genxml);
       btn_genxml.setOnClickListener(this);
        
       btn_parsejson = (Button) findViewById(R.id.parsejson);
       btn_parsejson.setOnClickListener(this);
        
       btn_genjson = (Button) findViewById(R.id.genjson);
       btn_genjson.setOnClickListener(this);
    }
    
    @Override
	public void onClick(View v) {
    	switch (v.getId()) {
    	case R.id.parsexmlbydom: {
    		parsexmlbydom();
    		break;
    	}
    	case R.id.parsexmlbysax: {
    		parsexmlbysax();
    		break;
    	}
    	case R.id.parsexmlbypull: {
    		parsexmlbypull();
    		break;
    	}
    	case R.id.genxml : {
    		genxml();
    		break;
    	}
    	case R.id.parsejson : {
    		parsejson();
    		break;
    	}
    	case R.id.genjson : {
    		genjson();
    		break;
    	}
    	}
    }
    
    public void parsexmlbydom() {
    	DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
    	DocumentBuilder builder;
		try {
			builder = builderFactory.newDocumentBuilder();
			InputStream is = getAssets().open("languages.xml");
	    	Document document = builder.parse(is);
	    	
	    	Element element = document.getDocumentElement();
	    	NodeList list = element.getElementsByTagName("lan");
	    	
	    	str_builder = new StringBuilder();
	    	for (int i = 0; i<list.getLength(); i++) {
	    		Element lan = (Element) list.item(i);
	    		// ����id
	    		str_builder.append(lan.getAttribute("id")).append("\n");
	    		
	    		// ����name
	    		NodeList name_list = element.getElementsByTagName("name");
	    		Element element_name = (Element) name_list.item(0);
	    		String str_name = element_name.getTextContent();
	    		str_builder.append(str_name).append("\n");
	    		
	    		//����ide
	    		NodeList ide_list = element.getElementsByTagName("ide");
	    		Element element_ide = (Element) ide_list.item(0);
	    		String str_ide = element_ide.getTextContent();
	    		str_builder.append(str_ide).append("\n");
	    		str_builder.append("----------------------------").append("\n");	
	    	}
	    	is.close();
	    	// �����������ʾ��textview��
	    	tv_result.setText(str_builder.toString());
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    }
    
    public void parsexmlbysax() {
    	str_builder = new StringBuilder();
    	SAXParserFactory factory = SAXParserFactory.newInstance();//����SAX��������
    	  SAXParser paser;
		try {
			paser = factory.newSAXParser();
			 LanguagePaser languagePaser=new LanguagePaser();//�����¼���������
	    	  
	    	  InputStream is = getAssets().open("languages.xml");
	    	  paser.parse(is,languagePaser);//��ʼ����
	    	  is.close();//�ر�������
	    	  
	    	  tv_result.setText(str_builder.toString());
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//����SAX������
        catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 
    }
    
	class LanguagePaser extends DefaultHandler {
		private String tagName = null;

		// �����ĵ���ʼ��ǵ�ʱ��
		@Override
		public void startDocument() throws SAXException {
			// TODO Auto-generated method stub
			super.startDocument();
		}

		// ����Ԫ�ؽڵ㿪ʼʱ��Ĵ�������
		@Override
		public void startElement(String uri, String localName, String qName,
				Attributes attributes) throws SAXException {
			tagName = localName;
			if ("lan".equals(tagName)) {
				// ȡ������ڵ�����
				str_builder.append(attributes.getValue(0)).append("\n");
			}

		}

		// �����ı��ڵ�ʱ�Ĳ���
		@Override
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			if (tagName != null) {
				String data = new String(ch, start, length);// ȡ���ı��ڵ��ֵ
				if ("name".equals(tagName)) {// ���ǰ���Ԫ�ؽڵ㿪ʼ�����name
					str_builder.append(data).append("\n");
				} else if ("ide".equals(tagName)) {// ���ǰ��Ԫ�ؽڵ㿪ʼ�����ide
					str_builder.append(data).append("\n");
				}
			}

		}

		// ����Ԫ�ؽڵ����ʱ��Ĳ���
		@Override
		public void endElement(String uri, String localName, String qName)
				throws SAXException {
			// TODO Auto-generated method stub
			super.endElement(uri, localName, qName);
		}
	}
    
    public void parsexmlbypull() {
    	  str_builder = new StringBuilder();
    	  XmlPullParser parser = Xml.newPullParser();//�õ�Pull������
    	  InputStream is;
		try {
			is = getAssets().open("languages.xml");
			
			parser.setInput(is, "UTF-8");//�������������ı���
	    	  int eventType = parser.getEventType();//�õ���һ���¼�����
	    	  while (eventType != XmlPullParser.END_DOCUMENT) {//����¼����Ͳ����ĵ������Ļ��򲻶ϴ����¼�
	    	   switch (eventType) {
	    	   case (XmlPullParser.START_DOCUMENT)://������ĵ���ʼ�¼�
	    	    break;
	    	   case (XmlPullParser.START_TAG)://���������ǩ��ʼ
	    	    String tagName = parser.getName();// ��ý�������ǰԪ�ص�����
	    	    if ("lan".equals(tagName)) {//�����ǰ��ǩ������<lau>
	    	     str_builder.append(parser.getAttributeValue(0)).append("\n");
	    	    }
	    	     if ("name".equals(tagName))//�����ǰ�ڵ�����name
	    	      
	    	     str_builder.append(parser.nextText()).append("\n");
	    	     else if ("ide".equals(tagName))//�����ǰԪ�ؽڵ�����ide
	    	      
	    	     str_builder.append(parser.nextText()).append("\n");
	    	   break;
	    	   case (XmlPullParser.END_TAG)://���������ǩ����
	    	    
	    	   break;
	    	   }
	    	   eventType=parser.next();//������һ���¼�����
	    	  }
	    	  tv_result.setText(str_builder.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
    }
    
    public void genxml() {
    	DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
    	DocumentBuilder builder;
		try {
			builder = builderFactory.newDocumentBuilder();
			
			Document newxml = builder.newDocument();
			Element languages = newxml.createElement("Languages");
			languages.setAttribute("cat", "it");
			
			// ������һ��lanԪ��
			Element lan1 = newxml.createElement("lan");
			lan1.setAttribute("id", "1");
			
			Element name1 = newxml.createElement("name");
			name1.setTextContent("Java");
			lan1.appendChild(name1);
			
			Element ide1 = newxml.createElement("ide");
			ide1.setTextContent("Eclipse");
			lan1.appendChild(ide1);
			
			languages.appendChild(lan1);
			
			// �����ڶ���lanԪ��
			Element lan2 = newxml.createElement("lan");
			lan2.setAttribute("id", "2");
			
			Element name2 = newxml.createElement("name");
			name2.setTextContent("Swift");
			lan2.appendChild(name2);
			
			Element ide2 = newxml.createElement("ide");
			ide2.setTextContent("Xcode");
			lan2.appendChild(ide2);	
			
			languages.appendChild(lan2);
			
			// ����������lanԪ��
			Element lan3 = newxml.createElement("lan");
			lan3.setAttribute("id", "3");
			
			Element name3 = newxml.createElement("name");
			name3.setTextContent("Swift");
			lan3.appendChild(name3);
			
			Element ide3 = newxml.createElement("ide");
			ide3.setTextContent("Xcode");
			lan3.appendChild(ide3);						
			languages.appendChild(lan3);
			
			newxml.appendChild(languages);
			
			// ���ֶ����ɵ�xml������ʾ��textview��
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transfromer = transformerFactory.newTransformer();
			transfromer.setOutputProperty("encoding", "utf-8");
			StringWriter sw = new StringWriter();
			transfromer.transform(new DOMSource(newxml), new StreamResult(sw));
			
			tv_result.setText(sw.toString());

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void parsejson() {
    	str_builder = new StringBuilder();
    	try {
			InputStream is = getAssets().open("language.json");
			InputStreamReader isr = new InputStreamReader(is, "utf-8");
			BufferedReader br = new BufferedReader(isr);
			
			String line;
			StringBuilder builder = new StringBuilder();
			while((line=br.readLine()) != null) {
				builder.append(line);
			}
			br.close();
			isr.close();
			is.close();
			
			JSONObject root = new JSONObject(builder.toString());
			str_builder.append("cat =").append(root.getString("cat")).append("\n");
			
			JSONArray array = root.getJSONArray("languages");
			for (int i=0;i<array.length(); i++) {
				JSONObject lan = array.getJSONObject(i);
				str_builder.append("------------------\n");
				str_builder.append("id =").append(lan.getInt("id")).append("\n");
				str_builder.append("name =").append(lan.getString("name")).append("\n");
				str_builder.append("ide =").append(lan.getString("ide")).append("\n");
			}
			tv_result.setText(str_builder.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void genjson() {
    	
    	try {
    		JSONObject root = new JSONObject();
			root.put("cat", "it");
			
			JSONObject lan1 = new JSONObject();
			lan1.put("id", 1);
			lan1.put("name", "java");
			lan1.put("ide", "Eclipse");
			
			JSONObject lan2 = new JSONObject();
			lan2.put("id", 2);
			lan2.put("name", "Swift");
			lan2.put("ide", "Xcode");
			
			JSONObject lan3 = new JSONObject();
			lan3.put("id", 3);
			lan3.put("name", "c++");
			lan3.put("ide", "Visual Studio");
			
			JSONArray array = new JSONArray();
			array.put(lan1);
			array.put(lan2);
			array.put(lan3);
			root.put("languages", array);
			
			tv_result.setText(root.toString());
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
